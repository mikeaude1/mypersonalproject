import{w as a}from"./chunk-U2YFPQFM.js";export{a as BlogModuleModule};
