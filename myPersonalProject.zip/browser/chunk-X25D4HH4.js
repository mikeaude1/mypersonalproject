import{w as a}from"./chunk-ZIAYEVU5.js";export{a as BlogModuleModule};
