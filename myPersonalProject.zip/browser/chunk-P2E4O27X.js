import{w as a}from"./chunk-HFK2VSMW.js";export{a as BlogModuleModule};
