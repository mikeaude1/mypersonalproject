import{w as a}from"./chunk-XWBCZFHX.js";export{a as BlogModuleModule};
