import{w as a}from"./chunk-SGLO22UA.js";export{a as BlogModuleModule};
