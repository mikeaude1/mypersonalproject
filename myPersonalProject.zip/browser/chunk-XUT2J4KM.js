import{w as a}from"./chunk-L6GNQWEM.js";export{a as BlogModuleModule};
