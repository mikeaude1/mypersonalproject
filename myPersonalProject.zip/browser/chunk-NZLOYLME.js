import{w as a}from"./chunk-IQUS44PN.js";export{a as BlogModuleModule};
