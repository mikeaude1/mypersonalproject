import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutPage',
  templateUrl: './aboutPage.component.html',
  styleUrls: ['./aboutPage.component.css']
})
export class AboutPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
