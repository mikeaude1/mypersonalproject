import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-component',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent {



  constructor() { }



}
