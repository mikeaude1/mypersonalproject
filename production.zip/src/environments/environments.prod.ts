export const environments={
  baseUrl: 'https://localhost:3000'
}
